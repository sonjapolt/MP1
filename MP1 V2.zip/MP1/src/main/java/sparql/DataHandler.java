package sparql;

import java.io.File;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;

public class DataHandler {

	public DataHandler() {

	}

	// http://www.w3.org/2003/01/geo/wgs84_pos#lat
	// http://www.w3.org/2003/01/geo/wgs84_pos#long
	public void queryLinkedGeoDataCategory(String category, int limit) {
		try {
			Query query = QueryFactory.create(
					"prefix lgdr: <http://linkedgeodata.org/triplify/>" + 
					"prefix lgdo: <http://linkedgeodata.org/ontology/>" + 
					"prefix rdfs: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>" + 
					"select ?s ?p ?o where {" + 
					"	?s ?p ?o ." + 
					"    	select ?s where {" + 
					"      		bind(lgdo:" + category + " as ?cat)" + 
					"			?s rdfs:type ?cat ." + 
					"    	}" + 
					"    	limit " + limit + 
					"  	}" + 
					"}");
			QueryExecution qexec = QueryExecutionFactory.sparqlService("http://linkedgeodata.org/sparql", query);
			ResultSet rs = qexec.execSelect();
			while (rs.hasNext()) {
				QuerySolution qs = rs.next();
				Iterator<String> itVars = qs.varNames();
				while (itVars.hasNext()) {
					Resource object;
					String szVar = itVars.next().toString();
					String szVal = qs.get(szVar).toString();
					System.out.println("[ " + szVar + " ] " + szVal);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
